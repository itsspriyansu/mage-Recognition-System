
import os
from flask import Flask, request, render_template
from tensorflow.keras.models import load_model
from utils import preprocess_image

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'

model = load_model('model/model.h5')
class_names = ['airplane', 'car', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']

@app.route('/', methods=['GET', 'POST'])
def index():
    prediction = None
    filename = None
    if request.method == 'POST':
        file = request.files['file']
        if file:
            filename = file.filename
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            image = preprocess_image(filepath)
            preds = model.predict(image)
            predicted_class = class_names[preds.argmax()]
            prediction = f"Prediction: {predicted_class}"
    return render_template('index.html', prediction=prediction, image_path=filename)

if __name__ == '__main__':
    app.run(debug=True)
